In that .zip file there are 4 tests which can be execuded by the initial program:
1. Simple test on the first part of the task
2. Simple (not) test on the second task: includes checks, castling and changing the state of the pawn (enter 1 during the execution)
3. Childish math algorithm
4. 'buggy' test, that checks unappropriate user's behaviour

To select the tests manualy, you should change the 'application.e' file